//
//  GZWindow.h
//  Compressor
//
//  Created by Glenn Zelniker on 4/15/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface GZWindow : NSWindow

{
	id delegate;
}

- (void)setDelegate:(id)sender;


@end

@interface NSObject (GZWindowDelegate)

- (void)gotMessage:(NSEvent *)e;

@end