//
//  MeterView.h
//  Compressor
//
//  Created by Glenn Zelniker on 1/5/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MeterView : NSImageView
{
	float gainReduction;
	
	float scale;
	
	float meterMax;	
}

-(void)setGainReduction:(float)l;

-(void)setSensitivity:(float)q;

-(void)setMax:(float)q;

@end
